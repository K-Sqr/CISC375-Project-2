const express = require('express');
const fs = require('fs');
//const parse = require('csv-parse/sync');
const { parse } = require('csv-parse/sync');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

// load CSV once at startup
const raw = fs.readFileSync(path.join(__dirname, 'data','drug-use-by-age.csv'));
const records = parse(raw, {columns: true, skip_empty_lines: true});

// helper to get unique ages and drugs
const ages = [...new Set(records.map(r => r.Age))];
const drugs = [...new Set(records.map(r => r.Drug))];

app.get('/', (req, res) => {
  // default home: by age listing first age
  res.redirect('/by-age/' + encodeURIComponent(ages[0]));
});

// route: view by age (shows all drugs for a given age)
app.get('/by-age/:age', (req, res) => {
  const age = req.params.age;
  const filtered = records.filter(r => r.Age === age);
  if (filtered.length === 0) {
    return res.status(404).send(`Error: no data for age ${age}`);
  }
  // previous / next age links
  const idx = ages.indexOf(age);
  const prev = idx > 0 ? ages[idx-1] : null;
  const next = idx < ages.length-1 ? ages[idx+1] : null;
  res.render('by-age', {age, data: filtered, ages, prev, next});
});

// route: view by drug (shows values across ages for a drug)
app.get('/by-drug/:drug', (req, res) => {
  const drug = req.params.drug;
  const filtered = records.filter(r => r.Drug === drug);
  if (filtered.length === 0) {
    return res.status(404).send(`Error: no data for drug ${drug}`);
  }
  // find index in drugs array
  const idx = drugs.indexOf(drug);
  const prev = idx > 0 ? drugs[idx-1] : null;
  const next = idx < drugs.length-1 ? drugs[idx+1] : null;
  res.render('by-drug', {drug, data: filtered, drugs, prev, next});
});

// route: summary view - show top drugs by average use
app.get('/summary', (req, res) => {
  // compute average percentage for each drug across ages
  const sums = {};
  const counts = {};
  records.forEach(r => {
    const d = r.Drug;
    const val = parseFloat(r.Value) || 0;
    sums[d] = (sums[d]||0) + val;
    counts[d] = (counts[d]||0) + 1;
  });
  const avg = Object.keys(sums).map(d => ({drug: d, avg: sums[d]/counts[d]}));
  avg.sort((a,b)=>b.avg-a.avg);
  res.render('summary', {avg});
});

// 404 handler for unknown routes
app.use((req,res) => {
  res.status(404).send(`Error: route ${req.originalUrl} not found`);
});

app.listen(PORT, ()=>console.log(`Server running on port ${PORT}`));