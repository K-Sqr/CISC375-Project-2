# Drug Use Dynamic Site

This project is a Node.js + Express + EJS web app visualizing `drug-use-by-age.csv` data.

## Setup

1. Make sure you have Node.js installed (https://nodejs.org/)
2. Extract this folder.
3. Open a terminal inside this folder and run:
   ```bash
   npm install
   npm start
   ```
4. Visit http://localhost:3000

## Notes
- The `node_modules` directory is intentionally excluded to keep file size small.
- Dependencies will be automatically downloaded via `npm install`.